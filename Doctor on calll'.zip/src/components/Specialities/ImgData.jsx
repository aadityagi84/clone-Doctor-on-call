export const clinicData = [
  {
    img: img1,
    surgen: "Urology"
  },
  {
    img: img2,
    surgen: "Neurology"
  },
  {
    img: img3,
    surgen: "Orthopedic"
  },
  {
    img: img4,
    surgen: "Cardiologist"
  },
  {
    img: img5,
    surgen: "Dentist"
  }
]
import img1 from '../images/specialities/specialities-01.png'
import img2 from '../images/specialities/specialities-02.png'
import img3 from '../images/specialities/specialities-03.png'
import img4 from '../images/specialities/specialities-04.png'
import img5 from '../images/specialities/specialities-05.png'
